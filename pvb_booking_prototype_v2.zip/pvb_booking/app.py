#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
=====================================================================
 ПВБ (Поволжский банк) — прототип бронирования помещений для юрлиц
=====================================================================
 Запуск:        python app.py
 Адрес:         http://127.0.0.1:5000
 Зависимостей:  НЕТ (только стандартная библиотека Python)
 База данных:   SQLite, файл pvb.db создаётся автоматически
                 при первом запуске и заполняется демо-данными.

 Роли:
   клиент         — вход на /login (регистрация на /register);
                    видит и отменяет только свои брони;
   администратор  — вход на /admin/login; видит все брони по всем
                    адресам и может отменить любую.
=====================================================================
"""
import hashlib
import hmac
import html
import json
import os
import re
import secrets
import sqlite3
import traceback
from datetime import date, datetime, timedelta
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlencode, urlparse

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "pvb.db")
STATIC_DIR = os.path.join(BASE_DIR, "static")

WORK_START = 9      # рабочие часы помещений: с 9:00
WORK_END = 20       #                            до 20:00
DAYS_AHEAD = 14     # на сколько дней вперёд открыт календарь
MAX_DURATION = 4    # максимум часов в одной брони

# ------------------------------------------------------- НАСТРОЙКИ ----
# Заглушка оферты/оплаты (шаг после подтверждения брони).
# Когда будет готово — впишите ссылки сюда, страница подхватит их сама.
# В PAYMENT_URL можно использовать {booking_id}, например:
#   PAYMENT_URL = "https://pay.example.ru/checkout?order={booking_id}"
OFFER_URL = ""
PAYMENT_URL = ""

# Администратор создаётся при первом запуске. Пароль лучше поменять
# (переменные окружения PVB_ADMIN_LOGIN / PVB_ADMIN_PASSWORD).
DEFAULT_ADMIN_PASSWORD = "admin123"
ADMIN_LOGIN = os.environ.get("PVB_ADMIN_LOGIN", "admin")
ADMIN_PASSWORD = os.environ.get("PVB_ADMIN_PASSWORD", DEFAULT_ADMIN_PASSWORD)

SESSION_COOKIE = "pvb_sid"
SESSION_DAYS = 7
MAX_BODY = 100_000

# ---------------------------------------------------------------- БД ----
SCHEMA = """
CREATE TABLE cities (
    id   INTEGER PRIMARY KEY,
    name TEXT NOT NULL
);
CREATE TABLE buildings (
    id      INTEGER PRIMARY KEY,
    city_id INTEGER NOT NULL REFERENCES cities(id),
    name    TEXT NOT NULL,
    address TEXT NOT NULL
);
CREATE TABLE rooms (
    id                  INTEGER PRIMARY KEY,
    building_id         INTEGER NOT NULL REFERENCES buildings(id),
    name                TEXT NOT NULL,
    area                REAL NOT NULL,             -- метраж, м²
    capacity            INTEGER NOT NULL,          -- вместимость, чел.
    tech_characteristics TEXT NOT NULL,            -- тех. характеристики
    equipment           TEXT NOT NULL,             -- оборудование
    price_per_hour      INTEGER NOT NULL,          -- ₽/час
    skud_required       INTEGER NOT NULL DEFAULT 0, -- нужна ли проходка (СКУД)
    photo               TEXT NOT NULL              -- заглушка фото
);
CREATE TABLE users (
    id         INTEGER PRIMARY KEY,
    role       TEXT NOT NULL CHECK (role IN ('client','admin')),
    login      TEXT NOT NULL UNIQUE,               -- клиент: e-mail, админ: логин
    pass_salt  TEXT NOT NULL,
    pass_hash  TEXT NOT NULL,
    name       TEXT NOT NULL,                      -- контактное лицо
    company    TEXT,
    phone      TEXT,
    email      TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE sessions (
    token      TEXT PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL
);
CREATE TABLE bookings (
    id            INTEGER PRIMARY KEY,
    room_id       INTEGER NOT NULL REFERENCES rooms(id),
    user_id       INTEGER REFERENCES users(id),    -- владелец брони (клиент)
    date          TEXT NOT NULL,                   -- YYYY-MM-DD
    start_time    INTEGER NOT NULL,                -- час начала (9..19)
    end_time      INTEGER NOT NULL,                -- час окончания (10..20)
    company_name  TEXT NOT NULL,                   -- название юрлица
    contact_name  TEXT NOT NULL,
    contact_phone TEXT NOT NULL,
    contact_email TEXT,
    comment       TEXT,
    created_at    TEXT NOT NULL
);
CREATE TABLE participants (
    id            INTEGER PRIMARY KEY,
    booking_id    INTEGER NOT NULL REFERENCES bookings(id),
    full_name     TEXT NOT NULL,
    passport_ser  TEXT NOT NULL,
    passport_num  TEXT NOT NULL,
    position      TEXT
);
"""

# Демо-данные (потом заменятся реальными)
CITIES = ["Ульяновск", "Самара", "Пенза", "Тольятти"]

BUILDINGS = {
    "Ульяновск": [
        ("Головное отделение ПВБ", "г. Ульяновск, ул. Ленина, д. 73"),
        ("Административное здание № 2", "г. Ульяновск, ул. Федерации, д. 12"),
    ],
    "Самара": [
        ("Головное отделение ПВБ", "г. Самара, ул. Куйбышева, д. 131"),
        ("Дополнительный офис «Самара-Центр»", "г. Самара, ул. Ленинградская, д. 70"),
    ],
    "Пенза": [
        ("Головное отделение ПВБ", "г. Пенза, ул. Московская, д. 59"),
    ],
    "Тольятти": [
        ("Дополнительный офис «Тольятти»", "г. Тольятти, б-р Королёва, д. 11"),
    ],
}

ROOM_TYPES = [
    # (название, метраж, вместимость, ₽/час, требуется СКУД, фото-заглушка)
    ("Переговорная комната", 28, 6, 500, 0, "room1.png"),
    ("Конференц-зал",        55, 20, 900, 1, "room2.png"),
    ("Офисное помещение",    38, 4, 650, 0, "room3.png"),
    ("Зал для встреч",       45, 12, 750, 1, "room4.png"),
]

TECH = [
    "Отделка: ковролин, натяжные потолки; кондиционер; естественное освещение",
    "Ремонт класса B; приточно-вытяжная вентиляция; кондиционер; окна во двор",
    "Современная отделка; сплит-система; blackout-шторы; электронные замки",
]
EQUIP = [
    "Стол конференц., 8 кресел, ТВ-панель 55\", флипчарт, Wi-Fi",
    "Проектор, экран, звуковая система, микрофоны, столы-банкетки до 20 чел.",
    "2 рабочих стола, кресла, шкаф, принтер (по запросу), Wi-Fi",
    "Круглый стол на 12 чел., ТВ-панель 65\", видеоконференцсвязь, флипчарт",
]

MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля",
          "августа", "сентября", "октября", "ноября", "декабря"]
WEEKDAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]


def get_db():
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


# ------------------------------------------------------ пароли/сессии ----
def hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                            salt.encode("ascii"), 200_000).hex()
    return salt, h


def check_password(password, salt, expected_hash):
    _, h = hash_password(password, salt)
    return hmac.compare_digest(h, expected_hash)


def add_user(db, role, login, password, name, company="", phone="", email=""):
    salt, h = hash_password(password)
    cur = db.execute(
        """INSERT INTO users (role, login, pass_salt, pass_hash, name, company,
                              phone, email, created_at)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (role, login, salt, h, name, company, phone, email,
         datetime.now().isoformat(timespec="seconds")))
    return cur.lastrowid


def create_session(db, user_id):
    token = secrets.token_urlsafe(32)
    db.execute("INSERT INTO sessions (token, user_id, created_at) VALUES (?,?,?)",
               (token, user_id, datetime.now().isoformat(timespec="seconds")))
    db.commit()
    return token


def user_by_token(token):
    if not token:
        return None
    db = get_db()
    try:
        limit = (datetime.now() - timedelta(days=SESSION_DAYS)).isoformat(timespec="seconds")
        db.execute("DELETE FROM sessions WHERE created_at < ?", (limit,))
        db.commit()
        return db.execute(
            """SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id
               WHERE s.token = ?""", (token,)).fetchone()
    finally:
        db.close()


# --------------------------------------------------------- инициализация ----
def init_db():
    """Создаёт БД и наполняет демо-данными (только при первом запуске),
    а для БД старой версии — аккуратно домигрирует структуру."""
    fresh = not os.path.exists(DB_PATH)
    db = get_db()
    if fresh:
        db.executescript(SCHEMA)
        seed_catalog(db)
    else:
        migrate(db)
    # администратор
    if not db.execute("SELECT 1 FROM users WHERE role='admin'").fetchone():
        add_user(db, "admin", ADMIN_LOGIN, ADMIN_PASSWORD, "Администратор")
    if fresh:
        seed_demo_bookings(db)
    db.commit()
    db.close()


def migrate(db):
    """Обновление БД из предыдущей версии прототипа."""
    tables = {r["name"] for r in db.execute(
        "SELECT name FROM sqlite_master WHERE type='table'")}
    if "users" not in tables or "sessions" not in tables:
        stmts = SCHEMA.split(";\n")
        for st in stmts:
            if "CREATE TABLE users" in st or "CREATE TABLE sessions" in st:
                db.execute(st)
    cols = {r["name"] for r in db.execute("PRAGMA table_info(bookings)")}
    if "user_id" not in cols:
        db.execute("ALTER TABLE bookings ADD COLUMN user_id INTEGER REFERENCES users(id)")
    if "status" in cols:
        # отменённые записи теперь удаляются физически
        ids = [r["id"] for r in db.execute(
            "SELECT id FROM bookings WHERE status='cancelled'")]
        for i in ids:
            db.execute("DELETE FROM participants WHERE booking_id=?", (i,))
            db.execute("DELETE FROM bookings WHERE id=?", (i,))
    db.commit()


def seed_catalog(db):
    for city in CITIES:
        cur = db.execute("INSERT INTO cities (name) VALUES (?)", (city,))
        city_id = cur.lastrowid
        for bname, addr in BUILDINGS[city]:
            cur = db.execute(
                "INSERT INTO buildings (city_id, name, address) VALUES (?,?,?)",
                (city_id, bname, addr))
            bld_id = cur.lastrowid
            for i, (rname, area, cap, price, skud, photo) in enumerate(ROOM_TYPES):
                db.execute(
                    """INSERT INTO rooms (building_id, name, area, capacity,
                                          tech_characteristics, equipment,
                                          price_per_hour, skud_required, photo)
                       VALUES (?,?,?,?,?,?,?,?,?)""",
                    (bld_id, f"{rname} «{chr(1040+i)}»", area, cap,
                     TECH[i % len(TECH)], EQUIP[i % len(EQUIP)],
                     price, skud, photo))


def seed_demo_bookings(db):
    """Два демо-клиента и по одной брони у каждого — чтобы было видно
    разницу между кабинетом клиента и администратора."""
    c1 = add_user(db, "client", "client@romashka.ru", "client123",
                  "Иванов Иван Иванович", "ООО «Ромашка»",
                  "+7 (900) 123-45-67", "client@romashka.ru")
    c2 = add_user(db, "client", "client2@sidorov.ru", "client123",
                  "Сидоров Пётр Андреевич", "ИП Сидоров",
                  "+7 (927) 555-12-34", "client2@sidorov.ru")
    tomorrow = (date.today() + timedelta(days=1)).isoformat()
    now = datetime.now().isoformat(timespec="seconds")
    cur = db.execute(
        """INSERT INTO bookings (room_id, user_id, date, start_time, end_time,
                                 company_name, contact_name, contact_phone,
                                 contact_email, comment, created_at)
           VALUES (1, ?, ?, 10, 13, 'ООО «Ромашка»', 'Иванов И.И.',
                   '+7 (900) 123-45-67', 'client@romashka.ru', 'Демо-запись', ?)""",
        (c1, tomorrow, now))
    db.execute(
        """INSERT INTO bookings (room_id, user_id, date, start_time, end_time,
                                 company_name, contact_name, contact_phone,
                                 contact_email, comment, created_at)
           VALUES (1, ?, ?, 15, 17, 'ИП Сидоров', 'Сидоров П.А.',
                   '+7 (927) 555-12-34', 'client2@sidorov.ru', '', ?)""",
        (c2, tomorrow, now))
    # конференц-зал (СКУД) с посетителями
    cur = db.execute(
        """INSERT INTO bookings (room_id, user_id, date, start_time, end_time,
                                 company_name, contact_name, contact_phone,
                                 contact_email, comment, created_at)
           VALUES (2, ?, ?, 14, 16, 'ООО «Ромашка»', 'Иванов И.И.',
                   '+7 (900) 123-45-67', 'client@romashka.ru', '', ?)""",
        (c1, tomorrow, now))
    bid = cur.lastrowid
    for p in (("Иванов Иван Иванович", "7301", "123456", "Директор"),
              ("Петрова Анна Сергеевна", "7302", "654321", "Бухгалтер")):
        db.execute(
            """INSERT INTO participants (booking_id, full_name, passport_ser,
                                         passport_num, position)
               VALUES (?,?,?,?,?)""", (bid,) + p)


# ------------------------------------------------------------ помощники ----
def esc(s):
    return html.escape(str(s if s is not None else ""))


def to_int(s, default=0):
    try:
        return int(s)
    except (TypeError, ValueError):
        return default


def money(n):
    return f"{n:,}".replace(",", " ") + " ₽"


def fmt_date(d):
    return f"{d.day} {MONTHS[d.month - 1]}"


def hh(h):
    return f"{h:02d}:00"


def safe_next(n):
    n = n or ""
    if n.startswith("/") and not n.startswith("//") and "\\" not in n:
        return n
    return "/"


def redir(path, **params):
    q = urlencode({k: v for k, v in params.items() if v not in (None, "")})
    return path + ("?" + q if q else "")


def first(data, key, default=""):
    v = data.get(key)
    return v[0] if v else default


def occupied_map(db, room_id, days):
    """{ 'YYYY-MM-DD': {час: строка_брони} } для календаря."""
    if not days:
        return {}
    rows = db.execute(
        """SELECT * FROM bookings WHERE room_id=? AND date BETWEEN ? AND ?""",
        (room_id, days[0], days[-1])).fetchall()
    out = {}
    for r in rows:
        for h in range(r["start_time"], r["end_time"]):
            out.setdefault(r["date"], {})[h] = r
    return out


def has_overlap(db, room_id, day, start, end):
    return db.execute(
        """SELECT 1 FROM bookings
           WHERE room_id=? AND date=? AND start_time < ? AND end_time > ?""",
        (room_id, day, end, start)).fetchone() is not None


def delete_booking(db, booking_id):
    db.execute("DELETE FROM participants WHERE booking_id=?", (booking_id,))
    db.execute("DELETE FROM bookings WHERE id=?", (booking_id,))
    db.commit()


# ------------------------------------------------------------ валидация ----
LET = "A-Za-zА-Яа-яЁё"
RE_PERSON = re.compile(rf"^[{LET}][{LET}\s.'\-]*$")
RE_COMPANY = re.compile(r"^[\w\s«»\"'“”.,\-&()№/+]+$")
RE_EMAIL = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}$")
RE_HAS_LETTER = re.compile(rf"[{LET}]")
RE_PHONE_CHARS = re.compile(r"^\+?[\d\s()\-]+$")
CTRL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")


def clean(s):
    s = CTRL.sub("", s or "")
    return re.sub(r"[ \t]+", " ", s).strip()


def v_person(s, label, min_words=1, required=True):
    s = clean(s)
    if not s:
        return s, (f"Укажите {label}" if required else None)
    if len(s) < 2 or len(s) > 80:
        return s, f"{label[0].upper() + label[1:]}: от 2 до 80 символов"
    if not RE_PERSON.match(s) or len(RE_HAS_LETTER.findall(s)) < 2:
        return s, f"{label[0].upper() + label[1:]} — только буквы, пробелы, точки и дефис (без цифр)"
    if len(s.split()) < min_words:
        return s, f"Укажите {label} полностью (фамилия и имя)"
    return s, None


def v_company(s):
    s = clean(s)
    if not s:
        return s, "Укажите название организации"
    if len(s) < 2 or len(s) > 120:
        return s, "Название организации: от 2 до 120 символов"
    if not RE_COMPANY.match(s) or not RE_HAS_LETTER.search(s):
        return s, "Название содержит недопустимые символы (допустимы буквы, цифры, « » \" . , - & ( ))"
    return s, None


def v_phone(s):
    s = clean(s)
    if not s:
        return s, "Укажите телефон"
    if not RE_PHONE_CHARS.match(s):
        return s, "Телефон: только цифры, пробелы, скобки, дефис и «+» в начале"
    d = re.sub(r"\D", "", s)
    if len(d) == 10:
        d = "7" + d
    elif len(d) == 11 and d[0] in "78":
        d = "7" + d[1:]
    else:
        return s, "Введите телефон в формате +7 (900) 123-45-67"
    if d[1] in "01":
        return s, "Неверный код оператора/города в телефоне"
    return f"+7 ({d[1:4]}) {d[4:7]}-{d[7:9]}-{d[9:11]}", None


def v_email(s, required=False):
    s = clean(s)
    if not s:
        return s, ("Укажите e-mail" if required else None)
    if len(s) > 100 or not RE_EMAIL.match(s):
        return s, "Введите корректный e-mail, например office@company.ru"
    return s.lower(), None


def v_comment(s):
    s = clean(s)
    if len(s) > 300:
        return s, "Комментарий: не более 300 символов"
    return s, None


def v_password(s):
    if len(s) < 8 or len(s) > 64:
        return "Пароль: от 8 до 64 символов"
    if not re.search(r"[A-Za-zА-Яа-яЁё]", s) or not re.search(r"\d", s):
        return "Пароль должен содержать и буквы, и цифры"
    return None


def v_position(s):
    s = clean(s)
    if not s:
        return s, None
    if len(s) > 60 or not re.match(rf"^[{LET}][{LET}\s.,\-]*$", s):
        return s, "Должность: только буквы (до 60 символов)"
    return s, None


# HTML-атрибуты проверки полей (клиентская валидация; серверная — в v_* ниже)
PAT_PERSON = "[A-Za-zА-Яа-яЁё][A-Za-zА-Яа-яЁё\\s.'\\-]*"
PAT_PHONE = "\\+7 \\(\\d{3}\\) \\d{3}-\\d{2}-\\d{2}"
EX_COMPANY = 'required minlength="2" maxlength="120" placeholder="ООО «Название»"'
EX_PERSON = ('required minlength="2" maxlength="80" pattern="' + PAT_PERSON + '" '
             'title="Только буквы, пробелы, точки и дефис" placeholder="Иванов И.И."')
EX_PERSON_FULL = EX_PERSON.replace("Иванов И.И.", "Иванов Иван Иванович")
EX_PHONE = ('required inputmode="tel" maxlength="18" placeholder="+7 (___) ___-__-__" '
            'pattern="' + PAT_PHONE + '" title="Формат: +7 (900) 123-45-67"')
EX_EMAIL = 'maxlength="100" placeholder="office@company.ru"'

# ---------------------------------------------------------- иконки / UI ----
ICONS = {
    "pin": '<path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
    "cal": '<rect x="3.5" y="5" width="17" height="15.5" rx="3"/><path d="M8 3v4M16 3v4M3.5 10h17"/>',
    "user": '<circle cx="12" cy="8" r="3.6"/><path d="M5 20c.8-3.6 3.6-5.4 7-5.4s6.2 1.8 7 5.4"/>',
    "area": '<rect x="4.5" y="4.5" width="15" height="15" rx="2.5"/><circle cx="12" cy="12" r="1.2"/>',
    "users": '<circle cx="9" cy="8.5" r="3.2"/><path d="M3 19.5c.6-3.2 3-4.8 6-4.8s5.4 1.6 6 4.8"/><path d="M16 5.5a3.2 3.2 0 0 1 0 6M18 14.8c1.7.6 2.7 2.1 3 4.4"/>',
    "arrow": '<path d="M5 12h14M13 6l6 6-6 6"/>',
    "clock": '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
    "doc": '<path d="M7 3.5h7l4 4V20a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4.5a1 1 0 0 1 1-1z"/><path d="M14 3.5V8h4M9 12.5h6M9 16h6"/>',
    "check": '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
}


def ico(name, cls=""):
    return (f'<svg class="ico {cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
            f'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" '
            f'aria-hidden="true">{ICONS[name]}</svg>')


def field(label, name, value="", err="", type="text", extra="", cls="", icon=""):
    """Поле в стиле макета: маленькая подпись внутри рамки + текст ошибки под ней."""
    bad = " has-err" if err else ""
    return (f'<div class="fcol {cls}"><div class="field{bad}">'
            f'<label for="f_{esc(name)}">{label}</label>'
            f'<input id="f_{esc(name)}" name="{esc(name)}" type="{type}" '
            f'value="{esc(value)}" {extra}>{icon}</div>'
            + (f'<div class="ferr">{esc(err)}</div>' if err else "") + '</div>')


def page(title, body, user=None, head_extra="", search=""):
    if user and user["role"] == "admin":
        links = ('<a href="/">Помещения</a><a href="/bookings">Все брони</a>')
        who = (f'<span class="who"><b>{esc(user["name"])}</b>'
               f'<span class="role role-admin">администратор</span></span>')
    elif user:
        links = ('<a href="/">Помещения</a><a href="/bookings">Мои брони</a>')
        who = (f'<span class="who"><b>{esc(user["company"] or user["name"])}</b>'
               f'<span class="role">клиент</span></span>')
    else:
        links = '<a href="/">Помещения</a>'
        who = ""
    if user:
        auth = (f'{who}<form method="post" action="/logout" class="inline">'
                f'<button class="link-btn">Выйти</button></form>')
    else:
        auth = ('<a class="btn btn-ghost btn-sm" href="/login">Войти</a>')
    return f"""<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(title)} — Бронирование помещений ПВБ</title>
<link rel="stylesheet" href="/static/css/style.css">
{head_extra}
</head>
<body>
<div class="userbar container">
  <nav class="links">{links}</nav>
  <div class="auth-box">{auth}</div>
</div>
<header class="topcard container">
  <a class="brand" href="/"><span class="brand-title">Бронирование помещений</span>
    <span class="brand-sub">Сервис бронирования онлайн · ПВБ</span></a>
  {search}
</header>
<main class="container">
{body}
</main>
<footer class="footer container">Прототип · данные сгенерированы для демонстрации · фото и схемы — заглушки</footer>
</body>
</html>"""


def flashes(qs):
    out = ""
    if "ok" in qs:
        out += f'<div class="flash flash-ok">{ico("check")} {esc(qs["ok"][0])}</div>'
    if "err" in qs:
        out += f'<div class="flash flash-err">{esc(qs["err"][0])}</div>'
    return out


def crumbs(*items):
    parts = []
    for i, it in enumerate(items):
        parts.append(it)
    return '<p class="crumbs">' + ' <span class="sep">›</span> '.join(parts) + '</p>'


def skud_status(r):
    if r["skud_required"]:
        return '<span class="status status-warn"><i></i>Нужна проходка (СКУД)</span>'
    return '<span class="status status-ok"><i></i>Открытое посещение</span>'


# --------------------------------------------------------- страницы: поиск ----
def page_home(qs, user):
    db = get_db()
    city_id = to_int(first(qs, "city"))
    bld_id = to_int(first(qs, "building"))
    cities = db.execute("SELECT * FROM cities ORDER BY name").fetchall()
    blds = db.execute("""SELECT b.*, c.name AS city_name FROM buildings b
                         JOIN cities c ON c.id=b.city_id
                         ORDER BY b.address""").fetchall()
    if bld_id and not city_id:
        b = next((b for b in blds if b["id"] == bld_id), None)
        if b:
            city_id = b["city_id"]
    sql = """SELECT r.*, b.name AS bname, b.address, b.city_id, c.name AS city_name
             FROM rooms r JOIN buildings b ON b.id=r.building_id
             JOIN cities c ON c.id=b.city_id WHERE 1=1"""
    params = []
    if bld_id:
        sql += " AND b.id=?"
        params.append(bld_id)
    elif city_id:
        sql += " AND c.id=?"
        params.append(city_id)
    sql += " ORDER BY c.name, b.address, r.name"
    rooms = db.execute(sql, params).fetchall()
    db.close()

    city_opts = '<option value="">Все города</option>' + "".join(
        f'<option value="{c["id"]}"{" selected" if c["id"] == city_id else ""}>{esc(c["name"])}</option>'
        for c in cities)
    bld_data = {}
    for b in blds:
        bld_data.setdefault(b["city_id"], []).append(
            {"id": b["id"], "t": b["address"]})
    search = f"""<form class="search" method="get" action="/">
  <div class="fcol"><div class="field"><label for="s_city">Город</label>
    <select id="s_city" name="city">{city_opts}</select>{ico("pin", "fi")}</div></div>
  <div class="fcol wide"><div class="field"><label for="s_bld">Адрес</label>
    <select id="s_bld" name="building"></select>{ico("pin", "fi")}</div></div>
  <button class="btn btn-primary">Показать помещения</button>
</form>
<script>
var BLD = {json.dumps(bld_data, ensure_ascii=False).replace("</", "<" + chr(92) + "/")};
var SEL = {bld_id};
function fillBld() {{
  var c = document.getElementById('s_city').value, s = document.getElementById('s_bld');
  var list = [];
  if (c) {{ list = BLD[c] || []; }}
  else {{ Object.keys(BLD).forEach(function(k) {{ list = list.concat(BLD[k]); }}); }}
  s.innerHTML = '<option value="">Все адреса</option>' + list.map(function(b) {{
    return '<option value="' + b.id + '"' + (b.id === SEL ? ' selected' : '') + '>' + b.t + '</option>';
  }}).join('');
}}
document.getElementById('s_city').addEventListener('change', function() {{ SEL = 0; fillBld(); }});
fillBld();
</script>"""

    groups = {}
    for r in rooms:
        groups.setdefault(r["building_id"], []).append(r)
    out = ""
    for bid, rs in groups.items():
        r0 = rs[0]
        out += (f'<div class="bld-head"><h2>{esc(r0["bname"])}</h2>'
                f'<span class="muted">{ico("pin", "inl")} {esc(r0["address"])}</span></div>'
                f'<div class="stack">{"".join(room_card(r) for r in rs)}</div>')
    if not out:
        out = '<div class="empty">По вашему запросу помещений не найдено.</div>'
    body = f"""{crumbs("Помещения", "Выберите помещение")}
{flashes(qs)}
{out}"""
    return page("Помещения", body, user, search=search)


def room_card(r):
    return f"""<article class="rcard">
  <img src="/static/img/{esc(r["photo"])}" alt="Фото помещения (заглушка)">
  <div class="rcard-main">
    <div class="rcard-top"><h3>{esc(r["name"])}</h3></div>
    <div class="meta">
      <span>{ico("area", "inl")} {r["area"]:g} м²</span>
      <span>{ico("users", "inl")} до {r["capacity"]} чел.</span>
    </div>
    {skud_status(r)}
    <p class="equip">{esc(r["equipment"])}</p>
    <div class="rcard-bottom">
      <span class="muted small">{ico("pin", "inl")} {esc(r["address"])}</span>
      <span class="price-box"><small>за час</small><b>{money(r["price_per_hour"])}</b></span>
      <a class="btn btn-primary btn-sm" href="/room?id={r["id"]}">Выбрать</a>
    </div>
  </div>
</article>"""


# ------------------------------------------------------ страницы: помещение ----
def page_room(room_id, qs, user):
    db = get_db()
    r = db.execute("""
        SELECT r.*, b.name AS bname, b.address, b.city_id, c.name AS city_name
        FROM rooms r JOIN buildings b ON b.id=r.building_id
        JOIN cities c ON c.id=b.city_id WHERE r.id=?""", (room_id,)).fetchone()
    if not r:
        db.close()
        return page("Ошибка", '<div class="empty">Помещение не найдено</div>', user)

    now = datetime.now()
    today = now.date()
    days = [(today + timedelta(days=d)).isoformat() for d in range(DAYS_AHEAD)]
    occ = occupied_map(db, room_id, days)
    db.close()

    is_admin = bool(user and user["role"] == "admin")
    head = "".join(f"<th>{h}:00</th>" for h in range(WORK_START, WORK_END))
    rows = ""
    for ds in days:
        day = date.fromisoformat(ds)
        cells = ""
        for h in range(WORK_START, WORK_END):
            b = occ.get(ds, {}).get(h)
            past = (day == today and h <= now.hour)
            if b is not None:
                mine = bool(user and b["user_id"] == user["id"] and user["role"] == "client")
                if mine:
                    cells += '<td><span class="slot slot-mine" title="Ваша бронь">ваша</span></td>'
                elif is_admin:
                    tip = f'{b["company_name"]} · {b["contact_name"]} · {b["contact_phone"]}'
                    cells += f'<td><span class="slot slot-busy" title="{esc(tip)}">{esc(b["company_name"][:9])}</span></td>'
                else:
                    cells += '<td><span class="slot slot-busy">занято</span></td>'
            elif past:
                cells += '<td><span class="slot slot-past">—</span></td>'
            elif is_admin:
                cells += '<td><span class="slot slot-free-ro">свободно</span></td>'
            else:
                cells += (f'<td><a class="slot slot-free" href="/book?room={room_id}'
                          f'&date={ds}&start={h}">+</a></td>')
        wd = WEEKDAYS[day.weekday()]
        wk = " wk" if day.weekday() >= 5 else ""
        rows += (f'<tr><th class="day{wk}" scope="row">{day.strftime("%d.%m")}'
                 f'<small>{wd}</small></th>{cells}</tr>')

    if is_admin:
        hint = "Вы вошли как администратор: на занятых слотах показано название организации (подробности — в разделе «Все брони»)."
    elif user:
        hint = "Нажмите «+» на свободном слоте, чтобы забронировать."
    else:
        hint = 'Нажмите «+» на свободном слоте. Для бронирования потребуется <a href="/login">войти</a>.'
    legend = ('<span class="lg lg-free"></span>свободно'
              '<span class="lg lg-busy"></span>занято'
              + ('<span class="lg lg-mine"></span>ваша бронь' if user and not is_admin else ""))

    body = f"""{crumbs('<a href="/">Помещения</a>', f'<a href="/?building={r["building_id"]}">{esc(r["bname"])}</a>', esc(r["name"]))}
{flashes(qs)}
<section class="card room-detail">
  <img src="/static/img/{esc(r["photo"])}" alt="Фото помещения (заглушка)">
  <div class="rd-info">
    <h1>{esc(r["name"])}</h1>
    <div class="meta">
      <span>{ico("area", "inl")} {r["area"]:g} м²</span>
      <span>{ico("users", "inl")} до {r["capacity"]} чел.</span>
      <span>{ico("pin", "inl")} {esc(r["city_name"])}, {esc(r["address"])}</span>
    </div>
    {skud_status(r)}
    {'<p class="muted small">При бронировании нужно указать состав посетителей (ФИО и паспорт).</p>' if r["skud_required"] else ""}
    <p><b>Тех. характеристики:</b> {esc(r["tech_characteristics"])}</p>
    <p><b>Оборудование:</b> {esc(r["equipment"])}</p>
    <div class="price-line"><b>{money(r["price_per_hour"])}</b> <span class="muted">за час</span></div>
  </div>
</section>
<section class="card">
  <div class="card-head"><h2>Доступность на {DAYS_AHEAD} дней</h2><div class="legend">{legend}</div></div>
  <p class="muted small">{hint} Рабочие часы: {WORK_START}:00–{WORK_END}:00.</p>
  <div class="cal-wrap"><table class="calendar"><thead><tr><th></th>{head}</tr></thead><tbody>{rows}</tbody></table></div>
</section>"""
    return page(r["name"], body, user)


# ------------------------------------------------------ страницы: бронь ----
def participant_row(i, v, e):
    def cell(name, ph, key, extra="", cls=""):
        err = e.get(key, "")
        return (f'<div class="fcol {cls}"><div class="field{" has-err" if err else ""}">'
                f'<label>{ph}</label><input name="{name}_{i}" value="{esc(v.get(key, ""))}" {extra}></div>'
                + (f'<div class="ferr">{esc(err)}</div>' if err else "") + '</div>')
    return (f'<div class="p-row">'
            + cell("p_name", "ФИО полностью *", "name",
                   'maxlength="80" required autocomplete="off"', "grow")
            + cell("p_ser", "Серия *", "ser",
                   'maxlength="4" inputmode="numeric" pattern="\\d{4}" title="4 цифры" required class="digits" data-len="4"', "w80")
            + cell("p_num", "Номер *", "num",
                   'maxlength="6" inputmode="numeric" pattern="\\d{6}" title="6 цифр" required class="digits" data-len="6"', "w100")
            + cell("p_pos", "Должность", "pos", 'maxlength="60"', "w150")
            + '<button type="button" class="btn-x" title="Удалить" onclick="rmP(this)">✕</button></div>')


def page_book_form(room_id, user, day, start, values=None, errors=None, parts=None):
    errors = errors or {}
    db = get_db()
    r = db.execute("""
        SELECT r.*, b.name AS bname, b.address, c.name AS city_name
        FROM rooms r JOIN buildings b ON b.id=r.building_id
        JOIN cities c ON c.id=b.city_id WHERE r.id=?""", (room_id,)).fetchone()
    db.close()
    if not r:
        return page("Ошибка", '<div class="empty">Помещение не найдено</div>', user)
    try:
        d = datetime.strptime(day, "%Y-%m-%d").date()
        start = int(start)
        assert WORK_START <= start < WORK_END
    except (ValueError, AssertionError, TypeError):
        return page("Ошибка", '<div class="empty">Некорректные дата/время. '
                    f'Выберите слот в <a href="/room?id={room_id}">календаре</a>.</div>', user)

    if values is None:
        values = {"company_name": user["company"] or "", "contact_name": user["name"] or "",
                  "contact_phone": user["phone"] or "", "contact_email": user["email"] or "",
                  "comment": "", "duration": "2"}
    dur = to_int(values.get("duration"), 2)
    if not 1 <= dur <= MAX_DURATION:
        dur = 2
    price = r["price_per_hour"]
    max_dur = min(MAX_DURATION, WORK_END - start)
    dur = min(dur, max_dur)

    gerr = errors.get("_form", "")
    err_div = f'<div class="flash flash-err">{esc(gerr)}</div>' if gerr else ""
    if errors and not gerr:
        err_div = '<div class="flash flash-err">Проверьте выделенные поля формы</div>'

    dur_opts = "".join(
        f'<option value="{k}"{" selected" if k == dur else ""}>{k} ч.</option>'
        for k in range(1, max_dur + 1))

    skud_block = ""
    if r["skud_required"]:
        parts = parts or [(1, {}, {})]
        rows = "".join(participant_row(i, v, e) for i, v, e in parts)
        perr = errors.get("_participants", "")
        skud_block = f"""
  <h3>Состав посетителей</h3>
  <p class="muted small">Помещение с проходкой (СКУД): укажите каждого, кто будет посещать помещение
     (до {r["capacity"]} чел.). Данные нужны для оформления пропусков.</p>
  {f'<div class="ferr">{esc(perr)}</div>' if perr else ""}
  <div id="plist">{rows}</div>
  <button type="button" class="btn btn-ghost btn-sm" onclick="addP()">+ Добавить посетителя</button>
  <template id="ptpl">{participant_row("__I__", {}, {})}</template>"""
    nmax = max([i for i, _, _ in (parts or [])] + [1])

    form = f"""
<form id="bookform" method="post" action="/book">
  <input type="hidden" name="room_id" value="{room_id}">
  <h3>Дата и время</h3>
  <div class="frow">
    {field("Дата", "date", d.isoformat(), errors.get("date", ""), extra="readonly", cls="w180", icon=ico("cal", "fi"))}
    {field("Начало", "start_time", hh(start), errors.get("start_time", ""), extra="readonly", cls="w140", icon=ico("clock", "fi"))}
    <div class="fcol w140"><div class="field"><label for="dur">Длительность</label>
      <select name="duration" id="dur">{dur_opts}</select></div></div>
  </div>
  <h3>Данные юридического лица</h3>
  <div class="frow">
    {field("Организация *", "company_name", values.get("company_name", ""), errors.get("company_name", ""),
           extra=EX_COMPANY, cls="grow")}
    {field("Контактное лицо *", "contact_name", values.get("contact_name", ""), errors.get("contact_name", ""),
           extra=EX_PERSON, cls="grow")}
  </div>
  <div class="frow">
    {field("Телефон *", "contact_phone", values.get("contact_phone", ""), errors.get("contact_phone", ""),
           type="tel", extra=EX_PHONE, cls="grow")}
    {field("E-mail", "contact_email", values.get("contact_email", ""), errors.get("contact_email", ""),
           type="email", extra=EX_EMAIL, cls="grow")}
  </div>
  <div class="frow">
    {field("Комментарий", "comment", values.get("comment", ""), errors.get("comment", ""),
           extra='maxlength="300" placeholder="Необязательно"', cls="grow")}
  </div>
  {skud_block}
</form>
<script>
var PRICE = {price}, START = {start}, SKUD = {1 if r["skud_required"] else 0}, NP = {nmax};
function money(n) {{ return String(n).replace(/\\B(?=(\\d{{3}})+(?!\\d))/g, '\\u00a0') + '\\u00a0₽'; }}
function two(n) {{ return (n < 10 ? '0' : '') + n; }}
function upd() {{
  var d = +document.getElementById('dur').value;
  document.getElementById('sum-time').textContent = two(START) + ':00–' + two(START + d) + ':00';
  document.getElementById('sum-hours').textContent = d + ' ч. × ' + money(PRICE);
  document.getElementById('sum-total').textContent = money(d * PRICE);
  if (SKUD) {{
    var n = document.querySelectorAll('#plist .p-row').length;
    document.getElementById('sum-people').textContent = n + ' посетител' + (n % 10 === 1 && n % 100 !== 11 ? 'ь' : (n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 'я' : 'ей'));
  }}
}}
document.getElementById('dur').addEventListener('change', upd);
// маска телефона
var ph = document.querySelector('input[type=tel]');
function fmtPhone(v) {{
  var d = v.replace(/\\D/g, '');
  if (d[0] === '8' || d[0] === '7') d = d.slice(1);
  d = d.slice(0, 10);
  var o = '+7';
  if (d.length) o += ' (' + d.slice(0, 3);
  if (d.length >= 3) o += ')';
  if (d.length > 3) o += ' ' + d.slice(3, 6);
  if (d.length > 6) o += '-' + d.slice(6, 8);
  if (d.length > 8) o += '-' + d.slice(8, 10);
  return o;
}}
ph.addEventListener('input', function() {{ if (ph.value) ph.value = fmtPhone(ph.value); }});
ph.addEventListener('focus', function() {{ if (!ph.value) ph.value = '+7 ('; }});
ph.addEventListener('blur', function() {{ if (ph.value.replace(/\\D/g, '').length <= 1) ph.value = ''; }});
if (ph.value) ph.value = fmtPhone(ph.value);
// посетители
function digitsOnly(root) {{
  root.querySelectorAll('.digits').forEach(function(i) {{
    i.addEventListener('input', function() {{ i.value = i.value.replace(/\\D/g, '').slice(0, +i.dataset.len); }});
  }});
}}
function addP() {{
  var t = document.getElementById('ptpl'); if (!t) return;
  NP++;
  var div = document.createElement('div');
  div.innerHTML = t.innerHTML.replace(/__I__/g, NP);
  var row = div.firstElementChild;
  document.getElementById('plist').appendChild(row);
  digitsOnly(row); upd();
}}
function rmP(b) {{
  var rows = document.querySelectorAll('#plist .p-row');
  if (rows.length > 1) {{ b.closest('.p-row').remove(); upd(); }}
}}
digitsOnly(document);
document.addEventListener('DOMContentLoaded', upd);
</script>"""

    people = (f'<div class="sum-line">{ico("users", "gi")}<span id="sum-people">1 посетитель</span></div>'
              if r["skud_required"] else "")
    panel = f"""<aside class="panel">
  <h2>Бронь</h2>
  <div class="sum-line big">{ico("cal", "gi")}<b>{fmt_date(d)}</b><span class="muted">{WEEKDAYS[d.weekday()]}</span></div>
  <div class="sum-line">{ico("clock", "gi")}<span id="sum-time">{hh(start)}–{hh(start + dur)}</span></div>
  {people}
  <hr>
  <div class="sum-row"><div><b>{esc(r["name"])}</b><div class="muted small">{esc(r["bname"])}</div>
     <div class="muted small">{esc(r["address"])}</div></div></div>
  <div class="sum-row"><span class="muted">Ставка</span><span id="sum-hours">{dur} ч. × {money(price)}</span></div>
  <hr>
  <div class="sum-row total"><b>Общая стоимость</b><b id="sum-total">{money(dur * price)}</b></div>
  <p class="muted small">Оплата — на следующем шаге, после ознакомления с офертой.</p>
  <button class="btn btn-primary btn-block btn-lg" form="bookform">Забронировать {ico("arrow", "inl")}</button>
</aside>"""

    body = f"""{crumbs('<a href="/">Помещения</a>', f'<a href="/room?id={room_id}">{esc(r["name"])}</a>', "Бронирование")}
<div class="layout">
  <section class="card">
    <h1>Бронирование</h1>
    <p class="muted">{esc(r["city_name"])} · {esc(r["bname"])} · {esc(r["address"])}</p>
    {err_div}
    {form}
  </section>
  {panel}
</div>"""
    return page("Бронирование", body, user)


def can_see(user, b):
    return user["role"] == "admin" or b["user_id"] == user["id"]


def page_booking_done(bid, qs, user):
    db = get_db()
    b = db.execute("""
        SELECT b.*, r.name AS rname, r.price_per_hour, r.skud_required,
               bd.name AS bname, bd.address, c.name AS city_name
        FROM bookings b JOIN rooms r ON r.id=b.room_id
        JOIN buildings bd ON bd.id=r.building_id JOIN cities c ON c.id=bd.city_id
        WHERE b.id=?""", (bid,)).fetchone()
    if not b or not can_see(user, b):
        db.close()
        return page("Ошибка", '<div class="empty">Бронь не найдена</div>', user)
    parts = db.execute("SELECT * FROM participants WHERE booking_id=?", (bid,)).fetchall()
    db.close()
    d = date.fromisoformat(b["date"])
    hours = b["end_time"] - b["start_time"]
    total = hours * b["price_per_hour"]

    plist = ""
    if parts:
        plist = ('<hr><h3>Посетители</h3><ul class="plain">' + "".join(
            f'<li>{esc(p["full_name"])}<span class="muted"> · паспорт {esc(p["passport_ser"])} {esc(p["passport_num"])}'
            f'{" · " + esc(p["position"]) if p["position"] else ""}</span></li>' for p in parts) + '</ul>')

    # ---- ЗАГЛУШКА: оферта и оплата -------------------------------------
    if OFFER_URL:
        offer_text = (f'<p>Ознакомьтесь с условиями оферты:</p>'
                      f'<p><a href="{esc(OFFER_URL)}" target="_blank" rel="noopener">Открыть оферту</a></p>')
    else:
        offer_text = ('<p><b>Здесь будет текст оферты.</b></p>'
                      '<p class="muted small">Раздел-заглушка: после подтверждения брони клиент увидит '
                      'условия договора-оферты и перейдёт к оплате по ссылке.</p>')
    if PAYMENT_URL:
        pay_btn = (f'<a class="btn btn-primary btn-block btn-lg" href="{esc(PAYMENT_URL.replace("{booking_id}", str(bid)))}">'
                   f'Перейти к оплате {ico("arrow", "inl")}</a>')
        pay_note = ""
    else:
        pay_btn = (f'<button class="btn btn-primary btn-block btn-lg" disabled>Перейти к оплате '
                   f'{ico("arrow", "inl")}</button>')
        pay_note = '<p class="muted small center">Ссылка на оплату появится позже.</p>'
    offer_panel = f"""<aside class="panel">
  <h2>Оферта и оплата</h2>
  <div class="offer-stub">{ico("doc", "offer-ico")}{offer_text}</div>
  <div class="sum-row total"><b>К оплате</b><b>{money(total)}</b></div>
  {pay_btn}
  {pay_note}
</aside>"""
    # --------------------------------------------------------------------

    owner = ""
    if user["role"] == "admin":
        db = get_db()
        u = db.execute("SELECT * FROM users WHERE id=?", (b["user_id"],)).fetchone() if b["user_id"] else None
        db.close()
        owner = f'<p class="muted small">Клиент: {esc(u["name"]) + " (" + esc(u["login"]) + ")" if u else "—"}</p>'
    head = ('<div class="flash flash-ok">' + ico("check") + ' Бронь создана, слот закреплён за вами</div>'
            if first(qs, "new") else "")
    body = f"""{crumbs('<a href="/">Помещения</a>', '<a href="/bookings">' + ("Все брони" if user["role"] == "admin" else "Мои брони") + '</a>', f"Бронь №{bid}")}
<div class="layout">
  <section class="card">
    {head}
    <h1>Бронь №{bid}</h1>
    {owner}
    <div class="sum-line big">{ico("cal", "gi")}<b>{fmt_date(d)}</b><span class="muted">{WEEKDAYS[d.weekday()]}</span>
       <span class="sep-dot">·</span><b>{hh(b["start_time"])}–{hh(b["end_time"])}</b></div>
    <hr>
    <div class="sum-row"><div><b>{esc(b["rname"])}</b>
        <div class="muted small">{esc(b["city_name"])}, {esc(b["address"])}</div></div></div>
    <div class="kv"><span>Организация</span><b>{esc(b["company_name"])}</b>
      <span>Контактное лицо</span><b>{esc(b["contact_name"])}</b>
      <span>Телефон</span><b>{esc(b["contact_phone"])}</b>
      <span>E-mail</span><b>{esc(b["contact_email"] or "—")}</b>
      <span>Комментарий</span><b>{esc(b["comment"] or "—")}</b>
      <span>Стоимость</span><b>{hours} ч. × {money(b["price_per_hour"])} = {money(total)}</b></div>
    {plist}
    <hr>
    <div class="actions">
      <a class="btn btn-ghost" href="/bookings">К списку броней</a>
      <form method="post" action="/cancel" class="inline" onsubmit="return confirm('Отменить бронь? Запись будет удалена, слот освободится.')">
        <input type="hidden" name="id" value="{bid}"><button class="btn btn-danger">Отменить бронь</button></form>
    </div>
  </section>
  {offer_panel}
</div>"""
    return page(f"Бронь №{bid}", body, user)


# --------------------------------------------------- страницы: список броней ----
def page_bookings(qs, user):
    db = get_db()
    is_admin = user["role"] == "admin"
    when = "past" if first(qs, "when") == "past" else "upcoming"
    bld_id = to_int(first(qs, "building")) if is_admin else 0
    today = date.today().isoformat()

    sql = """SELECT b.*, r.name AS rname, r.price_per_hour, bd.name AS bname,
                    bd.address, c.name AS city_name, u.login AS ulogin,
                    (SELECT COUNT(*) FROM participants p WHERE p.booking_id=b.id) AS n_p
             FROM bookings b
             JOIN rooms r ON r.id=b.room_id
             JOIN buildings bd ON bd.id=r.building_id
             JOIN cities c ON c.id=bd.city_id
             LEFT JOIN users u ON u.id=b.user_id
             WHERE 1=1"""
    params = []
    if not is_admin:
        sql += " AND b.user_id=?"
        params.append(user["id"])
    if bld_id:
        sql += " AND bd.id=?"
        params.append(bld_id)
    if when == "past":
        sql += " AND b.date < ? ORDER BY b.date DESC, b.start_time DESC"
    else:
        sql += " AND b.date >= ? ORDER BY b.date ASC, b.start_time ASC"
    params.append(today)
    rows = db.execute(sql, params).fetchall()
    parts_by = {}
    if rows:
        ids = [r["id"] for r in rows]
        for p in db.execute(
                f"SELECT * FROM participants WHERE booking_id IN ({','.join('?' * len(ids))})", ids):
            parts_by.setdefault(p["booking_id"], []).append(p)
    blds = db.execute("SELECT id, address FROM buildings ORDER BY address").fetchall() if is_admin else []
    db.close()

    cards = ""
    for b in rows:
        d = date.fromisoformat(b["date"])
        hours = b["end_time"] - b["start_time"]
        cost = hours * b["price_per_hour"]
        extra = ""
        if is_admin:
            extra += (f'<div class="small muted">Клиент (логин): {esc(b["ulogin"] or "—")}</div>')
        plist = parts_by.get(b["id"], [])
        if plist:
            extra += ('<details class="pd"><summary>Посетители: ' + str(len(plist)) + ' чел.</summary><ul class="plain">'
                      + "".join(f'<li>{esc(p["full_name"])}<span class="muted"> · {esc(p["passport_ser"])} {esc(p["passport_num"])}'
                                f'{" · " + esc(p["position"]) if p["position"] else ""}</span></li>' for p in plist)
                      + '</ul></details>')
        cancel = ""
        if when == "upcoming":
            cancel = (f'<form method="post" action="/cancel" class="inline" '
                      f'onsubmit="return confirm(\'Отменить бронь №{b["id"]}? Запись будет удалена, слот освободится.\')">'
                      f'<input type="hidden" name="id" value="{b["id"]}"><button class="btn btn-danger btn-sm">Отменить</button></form>')
        cards += f"""<article class="bk">
  <div class="bk-date"><b>{d.day}</b><span>{MONTHS[d.month - 1][:3]}</span><small>{WEEKDAYS[d.weekday()]}</small></div>
  <div class="bk-main">
    <div class="bk-title"><a href="/booking?id={b["id"]}"><b>{esc(b["rname"])}</b></a>
       <span class="muted small">№{b["id"]}</span></div>
    <div class="muted small">{ico("clock", "inl")} {hh(b["start_time"])}–{hh(b["end_time"])} · {ico("pin", "inl")} {esc(b["city_name"])}, {esc(b["address"])}</div>
    <div class="small">{esc(b["company_name"])} · {esc(b["contact_name"])} · {esc(b["contact_phone"])}</div>
    {extra}
  </div>
  <div class="bk-side"><b>{money(cost)}</b>{cancel}<a class="small" href="/booking?id={b["id"]}">Подробнее</a></div>
</article>"""
    if not cards:
        cards = '<div class="empty">Бронирований нет.</div>'

    def tab(w, label):
        cur = " on" if when == w else ""
        q = urlencode({k: v for k, v in (("when", w), ("building", bld_id or "")) if v != ""})
        return f'<a class="tab{cur}" href="/bookings?{q}">{label}</a>'

    filt = ""
    if is_admin:
        opts = '<option value="">Все адреса</option>' + "".join(
            f'<option value="{b["id"]}"{" selected" if b["id"] == bld_id else ""}>{esc(b["address"])}</option>' for b in blds)
        filt = f"""<form method="get" action="/bookings" class="filter">
  <input type="hidden" name="when" value="{when}">
  <div class="fcol wide"><div class="field"><label for="fb">Адрес</label>
    <select id="fb" name="building" onchange="this.form.submit()">{opts}</select>{ico("pin", "fi")}</div></div>
</form>"""
    title = "Все брони" if is_admin else "Мои брони"
    sub = ("Все записи по всем адресам." if is_admin
           else "Здесь только ваши записи. Отменённая бронь удаляется, слот сразу освобождается.")
    body = f"""{crumbs('<a href="/">Помещения</a>', title)}
<div class="head-row"><div><h1>{title}</h1><p class="muted">{sub}</p></div>{filt}</div>
{flashes(qs)}
<div class="tabs">{tab("upcoming", "Предстоящие")}{tab("past", "Прошедшие")}<span class="muted small">Найдено: {len(rows)}</span></div>
<div class="stack">{cards}</div>"""
    return page(title, body, user)


# ----------------------------------------------------- страницы: вход ----
def auth_switch(role):
    return (f'<div class="seg"><a class="{"on" if role == "client" else ""}" href="/login">Я клиент</a>'
            f'<a class="{"on" if role == "admin" else ""}" href="/admin/login">Администратор</a></div>')


def page_login(role, nxt="", login="", err="", qs=None):
    action = "/login" if role == "client" else "/admin/login"
    title = "Вход для клиента" if role == "client" else "Вход для администратора"
    lbl = "E-mail" if role == "client" else "Логин"
    hint = ""
    if role == "client":
        hint = ('<div class="hint">Демо-клиент: <b>client@romashka.ru</b> / <b>client123</b></div>')
        alt = '<p class="center muted">Нет аккаунта? <a href="/register">Зарегистрироваться</a></p>'
    else:
        if ADMIN_PASSWORD == DEFAULT_ADMIN_PASSWORD:
            hint = (f'<div class="hint">Демо-администратор: <b>{esc(ADMIN_LOGIN)}</b> / <b>{DEFAULT_ADMIN_PASSWORD}</b></div>')
        alt = '<p class="center muted small">Вход только для сотрудников банка.</p>'
    body = f"""<div class="auth card">
  {auth_switch(role)}
  <h1>{title}</h1>
  {flashes(qs or {})}
  {f'<div class="flash flash-err">{esc(err)}</div>' if err else ""}
  <form method="post" action="{action}">
    <input type="hidden" name="next" value="{esc(nxt)}">
    {field(lbl, "login", login, extra='required autocomplete="username" maxlength="100"')}
    {field("Пароль", "password", "", type="password", extra='required autocomplete="current-password" maxlength="64"')}
    <button class="btn btn-primary btn-block btn-lg">Войти {ico("arrow", "inl")}</button>
  </form>
  {hint}
  {alt}
</div>"""
    return page(title, body, None)


def page_register(values=None, errors=None, nxt=""):
    values = values or {}
    errors = errors or {}
    body = f"""<div class="auth card wide">
  {auth_switch("client")}
  <h1>Регистрация клиента</h1>
  <p class="muted">Аккаунт нужен, чтобы бронировать помещения и видеть свои записи.</p>
  {'<div class="flash flash-err">Проверьте выделенные поля формы</div>' if errors else ""}
  <form method="post" action="/register">
    <input type="hidden" name="next" value="{esc(nxt)}">
    <div class="frow">
    {field("Организация *", "company", values.get("company", ""), errors.get("company", ""), extra=EX_COMPANY, cls="grow")}
    {field("Контактное лицо *", "name", values.get("name", ""), errors.get("name", ""), extra=EX_PERSON_FULL, cls="grow")}
    </div>
    <div class="frow">
    {field("Телефон *", "phone", values.get("phone", ""), errors.get("phone", ""), type="tel", extra=EX_PHONE, cls="grow")}
    {field("E-mail (он же логин) *", "email", values.get("email", ""), errors.get("email", ""), type="email", extra='required maxlength="100" autocomplete="username" placeholder="office@company.ru"', cls="grow")}
    </div>
    <div class="frow">
    {field("Пароль *", "password", "", errors.get("password", ""), type="password", extra='required minlength="8" maxlength="64" autocomplete="new-password" placeholder="не менее 8 символов, буквы и цифры"', cls="grow")}
    {field("Повторите пароль *", "password2", "", errors.get("password2", ""), type="password", extra='required maxlength="64" autocomplete="new-password"', cls="grow")}
    </div>
    <button class="btn btn-primary btn-block btn-lg">Зарегистрироваться {ico("arrow", "inl")}</button>
  </form>
  <p class="center muted">Уже есть аккаунт? <a href="/login">Войти</a></p>
</div>
<script>
var ph = document.querySelector('input[type=tel]');
function fmtPhone(v) {{
  var d = v.replace(/\\D/g, ''); if (d[0] === '8' || d[0] === '7') d = d.slice(1); d = d.slice(0, 10);
  var o = '+7'; if (d.length) o += ' (' + d.slice(0, 3); if (d.length >= 3) o += ')';
  if (d.length > 3) o += ' ' + d.slice(3, 6); if (d.length > 6) o += '-' + d.slice(6, 8); if (d.length > 8) o += '-' + d.slice(8, 10);
  return o;
}}
ph.addEventListener('input', function() {{ if (ph.value) ph.value = fmtPhone(ph.value); }});
ph.addEventListener('focus', function() {{ if (!ph.value) ph.value = '+7 ('; }});
ph.addEventListener('blur', function() {{ if (ph.value.replace(/\\D/g, '').length <= 1) ph.value = ''; }});
if (ph.value) ph.value = fmtPhone(ph.value);
</script>"""
    return page("Регистрация", body, None)


# ---------------------------------------------------------- обработка ----
def do_book(data, user):
    """Возвращает (redirect_url, None) при успехе или (None, html) с ошибками."""
    errors = {}
    room_id = to_int(first(data, "room_id"))
    day = first(data, "date")
    start = to_int(first(data, "start_time").split(":")[0], -1)
    duration = to_int(first(data, "duration"), 0)

    db = get_db()
    try:
        r = db.execute("SELECT * FROM rooms WHERE id=?", (room_id,)).fetchone()
        if not r:
            return redir("/", err="Помещение не найдено"), None

        values = {k: first(data, k) for k in
                  ("company_name", "contact_name", "contact_phone", "contact_email", "comment")}
        values["duration"] = str(duration)

        # --- слот
        now = datetime.now()
        d = None
        try:
            d = date.fromisoformat(day)
        except ValueError:
            errors["_form"] = "Некорректная дата"
        if d is not None:
            if d < now.date():
                errors["_form"] = "Нельзя бронировать прошедшую дату"
            elif d > now.date() + timedelta(days=DAYS_AHEAD - 1):
                errors["_form"] = f"Бронирование открыто на {DAYS_AHEAD} дней вперёд"
        if not WORK_START <= start < WORK_END:
            errors["_form"] = f"Некорректное время (рабочие часы {WORK_START}:00–{WORK_END}:00)"
        elif d == now.date() and start <= now.hour:
            errors["_form"] = "Это время уже прошло, выберите другой слот"
        if not 1 <= duration <= MAX_DURATION:
            errors["_form"] = f"Длительность: от 1 до {MAX_DURATION} часов"
        end = start + duration
        if "_form" not in errors and end > WORK_END:
            errors["_form"] = f"Бронь должна заканчиваться не позже {WORK_END}:00"

        # --- поля юрлица
        values["company_name"], e = v_company(values["company_name"])
        if e:
            errors["company_name"] = e
        values["contact_name"], e = v_person(values["contact_name"], "контактное лицо")
        if e:
            errors["contact_name"] = e
        values["contact_phone"], e = v_phone(values["contact_phone"])
        if e:
            errors["contact_phone"] = e
        values["contact_email"], e = v_email(values["contact_email"])
        if e:
            errors["contact_email"] = e
        values["comment"], e = v_comment(values["comment"])
        if e:
            errors["comment"] = e

        # --- посетители (СКУД)
        parts_ui, parts_db, seen = [], [], set()
        if r["skud_required"]:
            idxs = sorted({int(m.group(1)) for k in data
                           for m in [re.match(r"^p_(?:name|ser|num|pos)_(\d{1,4})$", k)] if m})
            for i in idxs:
                raw = {"name": first(data, f"p_name_{i}"), "ser": first(data, f"p_ser_{i}"),
                       "num": first(data, f"p_num_{i}"), "pos": first(data, f"p_pos_{i}")}
                if not any(clean(v) for v in raw.values()):
                    continue
                pe = {}
                name, e = v_person(raw["name"], "ФИО посетителя", min_words=2)
                if e:
                    pe["name"] = e
                ser = re.sub(r"\s", "", raw["ser"])
                num = re.sub(r"\s", "", raw["num"])
                if not re.fullmatch(r"\d{4}", ser):
                    pe["ser"] = "Серия — 4 цифры"
                if not re.fullmatch(r"\d{6}", num):
                    pe["num"] = "Номер — 6 цифр"
                pos, e = v_position(raw["pos"])
                if e:
                    pe["pos"] = e
                if not pe:
                    if (ser, num) in seen:
                        pe["num"] = "Посетитель с таким паспортом уже указан"
                    seen.add((ser, num))
                parts_ui.append((i, {"name": name, "ser": ser, "num": num, "pos": pos}, pe))
                parts_db.append((name, ser, num, pos))
                if pe:
                    errors[f"_p{i}"] = "1"
            if not parts_ui:
                errors["_participants"] = "Для помещения с СКУД укажите хотя бы одного посетителя"
            elif len(parts_ui) > r["capacity"]:
                errors["_participants"] = f"Посетителей не больше вместимости помещения ({r['capacity']} чел.)"

        def show():
            return None, page_book_form(room_id, user, day if d else "", start, values,
                                        errors, parts_ui or None)

        if errors:
            if d is None or not WORK_START <= start < WORK_END:
                return redir("/room", id=room_id, err=errors.get("_form", "Некорректные данные")), None
            return show()

        # --- запись в БД: проверка пересечения и вставка в одной транзакции
        db.isolation_level = None
        db.execute("BEGIN IMMEDIATE")
        try:
            if has_overlap(db, room_id, day, start, end):
                db.execute("ROLLBACK")
                errors["_form"] = "Этот слот уже занят, выберите другое время"
                return show()
            cur = db.execute("""
                INSERT INTO bookings (room_id, user_id, date, start_time, end_time,
                        company_name, contact_name, contact_phone, contact_email,
                        comment, created_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)""", (
                room_id, user["id"], day, start, end, values["company_name"],
                values["contact_name"], values["contact_phone"], values["contact_email"],
                values["comment"], now.isoformat(timespec="seconds")))
            bid = cur.lastrowid
            for p in parts_db:
                db.execute("""INSERT INTO participants (booking_id, full_name,
                                  passport_ser, passport_num, position)
                              VALUES (?,?,?,?,?)""", (bid,) + p)
            db.execute("COMMIT")
        except Exception:
            try:
                db.execute("ROLLBACK")
            except sqlite3.Error:
                pass
            raise
        return redir("/booking", id=bid, new=1), None
    finally:
        db.close()


def do_register(data):
    values = {k: first(data, k) for k in ("company", "name", "phone", "email")}
    errors = {}
    values["company"], e = v_company(values["company"])
    if e:
        errors["company"] = e
    values["name"], e = v_person(values["name"], "контактное лицо")
    if e:
        errors["name"] = e
    values["phone"], e = v_phone(values["phone"])
    if e:
        errors["phone"] = e
    values["email"], e = v_email(values["email"], required=True)
    if e:
        errors["email"] = e
    pw, pw2 = first(data, "password"), first(data, "password2")
    e = v_password(pw)
    if e:
        errors["password"] = e
    elif pw != pw2:
        errors["password2"] = "Пароли не совпадают"
    if errors:
        return None, values, errors
    db = get_db()
    try:
        if db.execute("SELECT 1 FROM users WHERE login=?", (values["email"],)).fetchone():
            return None, values, {"email": "Клиент с таким e-mail уже зарегистрирован"}
        uid = add_user(db, "client", values["email"], pw, values["name"],
                       values["company"], values["phone"], values["email"])
        db.commit()
        return uid, values, {}
    finally:
        db.close()


CONTENT_TYPES = {".css": "text/css; charset=utf-8", ".png": "image/png",
                 ".jpg": "image/jpeg", ".svg": "image/svg+xml",
                 ".js": "application/javascript; charset=utf-8",
                 ".ico": "image/x-icon"}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    # ---- ответы
    def _send(self, body, ctype="text/html; charset=utf-8", code=200, headers=()):
        b = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in headers:
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(b)

    def _redirect(self, location, headers=()):
        self.send_response(303)
        self.send_header("Location", location)
        self.send_header("Content-Length", "0")
        for k, v in headers:
            self.send_header(k, v)
        self.end_headers()

    def _user(self):
        raw = self.headers.get("Cookie", "")
        try:
            c = SimpleCookie(raw)
        except Exception:
            return None
        m = c.get(SESSION_COOKIE)
        return user_by_token(m.value if m else None)

    def _cookie(self, token, max_age):
        return ("Set-Cookie",
                f"{SESSION_COOKIE}={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={max_age}")

    def _login_redirect(self):
        self._redirect(redir("/login", next=self.path, err="Войдите, чтобы продолжить"))

    # ---- GET
    def do_GET(self):
        u = urlparse(self.path)
        path, qs = u.path, parse_qs(u.query)

        if path.startswith("/static/"):
            root = os.path.realpath(STATIC_DIR)
            fp = os.path.realpath(os.path.join(root, path[len("/static/"):]))
            if fp.startswith(root + os.sep) and os.path.isfile(fp):
                ext = os.path.splitext(fp)[1].lower()
                with open(fp, "rb") as f:
                    self._send(f.read(), CONTENT_TYPES.get(ext, "application/octet-stream"),
                               headers=[("Cache-Control", "no-cache")])
            else:
                self._send("not found", code=404)
            return

        user = self._user()
        try:
            if path == "/":
                return self._send(page_home(qs, user))
            if path == "/city":
                return self._redirect(redir("/", city=to_int(first(qs, "id"))))
            if path == "/building":
                return self._redirect(redir("/", building=to_int(first(qs, "id"))))
            if path == "/room":
                return self._send(page_room(to_int(first(qs, "id")), qs, user))
            if path in ("/login", "/admin/login"):
                if user:
                    return self._redirect("/")
                role = "client" if path == "/login" else "admin"
                return self._send(page_login(role, safe_next(first(qs, "next")), qs=qs))
            if path == "/register":
                if user:
                    return self._redirect("/")
                return self._send(page_register(nxt=safe_next(first(qs, "next"))))
            # ---- дальше только для вошедших
            if path in ("/book", "/booking", "/bookings"):
                if not user:
                    return self._login_redirect()
                if path == "/bookings":
                    return self._send(page_bookings(qs, user))
                if path == "/booking":
                    return self._send(page_booking_done(to_int(first(qs, "id")), qs, user))
                if user["role"] != "client":
                    return self._redirect(redir("/room", id=to_int(first(qs, "room")),
                                                err="Бронировать могут только клиенты. Администратор просматривает записи."))
                return self._send(page_book_form(
                    to_int(first(qs, "room")), user, first(qs, "date"), first(qs, "start")))
            self._send(page("404", '<div class="empty">Страница не найдена</div>', user), code=404)
        except Exception:
            traceback.print_exc()
            self._send(page("Ошибка", '<div class="empty">Что-то пошло не так. Попробуйте ещё раз.</div>', user),
                       code=500)

    # ---- POST
    def do_POST(self):
        u = urlparse(self.path)
        length = to_int(self.headers.get("Content-Length"), 0)
        if length > MAX_BODY:
            return self._send("Слишком большой запрос", code=413)
        data = parse_qs(self.rfile.read(length).decode("utf-8", "replace"))
        user = self._user()
        try:
            if u.path in ("/login", "/admin/login"):
                return self._post_login(u.path, data)
            if u.path == "/register":
                uid, values, errors = do_register(data)
                if errors:
                    return self._send(page_register(values, errors, safe_next(first(data, "next"))))
                db = get_db()
                token = create_session(db, uid)
                db.close()
                return self._redirect(safe_next(first(data, "next")) if first(data, "next") else
                                      redir("/", ok="Регистрация завершена. Добро пожаловать!"),
                                      [self._cookie(token, SESSION_DAYS * 86400)])
            if u.path == "/logout":
                raw = self.headers.get("Cookie", "")
                m = SimpleCookie(raw).get(SESSION_COOKIE) if raw else None
                if m:
                    db = get_db()
                    db.execute("DELETE FROM sessions WHERE token=?", (m.value,))
                    db.commit()
                    db.close()
                return self._redirect("/", [self._cookie("", 0)])

            if not user:
                return self._login_redirect()
            if u.path == "/book":
                if user["role"] != "client":
                    return self._redirect(redir("/", err="Бронировать могут только клиенты"))
                url, html_ = do_book(data, user)
                return self._redirect(url) if url else self._send(html_)
            if u.path == "/cancel":
                bid = to_int(first(data, "id"))
                db = get_db()
                b = db.execute("SELECT * FROM bookings WHERE id=?", (bid,)).fetchone()
                if not b or not can_see(user, b):
                    db.close()
                    return self._redirect(redir("/bookings", err="Бронь не найдена"))
                delete_booking(db, bid)
                db.close()
                return self._redirect(redir("/bookings", ok=f"Бронь №{bid} отменена и удалена, слот освобождён"))
            self._redirect("/")
        except Exception:
            traceback.print_exc()
            self._send(page("Ошибка", '<div class="empty">Что-то пошло не так. Попробуйте ещё раз.</div>', user),
                       code=500)

    def _post_login(self, path, data):
        role = "client" if path == "/login" else "admin"
        login = clean(first(data, "login"))
        if role == "client":
            login = login.lower()
        password = first(data, "password")
        nxt = safe_next(first(data, "next"))
        db = get_db()
        try:
            row = db.execute("SELECT * FROM users WHERE login=? AND role=?", (login, role)).fetchone()
            ok = False
            if row:
                ok = check_password(password, row["pass_salt"], row["pass_hash"])
            else:
                hash_password(password)   # выравниваем время ответа
            if not ok:
                return self._send(page_login(role, nxt, login, "Неверный логин или пароль"), code=200)
            token = create_session(db, row["id"])
        finally:
            db.close()
        target = nxt if nxt != "/" else ("/bookings" if role == "admin" else "/")
        self._redirect(target, [self._cookie(token, SESSION_DAYS * 86400)])


def run(host="127.0.0.1", port=5000):
    init_db()
    srv = ThreadingHTTPServer((host, port), Handler)
    print(f"Прототип запущен: http://{host}:{port}  (Ctrl+C — остановить)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    run()
